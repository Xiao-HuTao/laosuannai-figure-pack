# 老酸奶

版本 2.1.0-preview · 0 组打扮、37 个表情和动作、0 个音效。

在形象管理界面直接导入 ZIP，无需解压。沿用原形象 ID，将更新同一角色。

采用已确认的 2.1.0 表情与眨眼校准；没有新增头部鼠标追踪。代码、参数和图片均已包含，宿主提供 API 2 的 kit 接口。署名与许可见 CREDITS.md 和 LICENSE。

形象包作者：[Xiao-HuTao](https://github.com/Xiao-HuTao)。

作者与发布来源：https://github.com/Xiao-HuTao
